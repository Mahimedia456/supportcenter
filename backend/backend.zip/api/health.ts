export default function handler(
  _req: any,
  res: any,
) {
  return res.status(200).json({
    ok: true,
    service: 'Support Command Center API',
    environment: 'vercel',
    timestamp: new Date().toISOString(),
  });
}
